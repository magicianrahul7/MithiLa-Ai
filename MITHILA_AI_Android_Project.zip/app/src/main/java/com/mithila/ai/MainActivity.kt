package com.mithila.ai

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("mithila", MODE_PRIVATE) }
    private val voiceRequest = 71
    private val colors = intArrayOf(Color.rgb(15, 23, 42), Color.rgb(30, 41, 59))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("MITHILA AI", "Namaste! Main MITHILA AI hoon. Hindi ya Hinglish mein command likho ya mic dabakar bolo. Abhi app-opening, web search, notes, reminders aur AI chat support karta hoon.")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 12)
            setBackgroundColor(Color.rgb(9, 14, 28))
        }
        val title = TextView(this).apply {
            text = "✦ MITHILA AI"
            textSize = 26f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }
        status = TextView(this).apply {
            text = "Hindi • Hinglish • Voice"
            textSize = 13f; setTextColor(Color.rgb(125, 211, 252))
            setPadding(0, 4, 0, 12)
        }
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            addView(chat)
            isFillViewport = true
        }
        input = EditText(this).apply {
            hint = "Apni command likho…"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(false); maxLines = 3
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(30, 41, 59))
        }
        val send = Button(this).apply { text = "Bhejo"; setOnClickListener { sendCommand() } }
        val mic = Button(this).apply { text = "🎙 Bolo"; setOnClickListener { startVoice() } }
        val voice = Button(this).apply { text = "🔊 Voice test"; setOnClickListener {
            speak("Namaste! Main MITHILA AI hoon. Aapki kya madad kar sakta hoon?")
        } }
        val settings = Button(this).apply { text = "API key"; setOnClickListener { askApiKey() } }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(send, LinearLayout.LayoutParams(0, -2, 1f))
            addView(mic, LinearLayout.LayoutParams(0, -2, 1f))
            addView(voice, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(title)
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        root.addView(row)
        root.addView(settings)
        setContentView(root)
    }

    private fun addMessage(who: String, message: String) {
        runOnUiThread {
            val tv = TextView(this).apply {
                text = "$who\n$message"
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(13, 10, 13, 10)
                setBackgroundColor(if (who == "Tum") Color.rgb(30, 64, 90) else Color.rgb(30, 41, 59))
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 5, 0, 5)
            chat.addView(tv, lp)
        }
    }

    private fun sendCommand() {
        val command = input.text.toString().trim()
        if (command.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        addMessage("Tum", command)
        handleCommand(command)
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT)
        when {
            c == "help" || c.contains("kya kar sakte") || c.contains("madad") -> {
                respond("Aap keh sakte hain: YouTube kholo, Google par BGMI search karo, note likho ..., notes dikhao, reminder lagao ..., ya koi sawal poochho.")
            }
            c.contains("youtube") && (c.contains("kholo") || c.contains("open")) -> openUrl("https://www.youtube.com")
            c.contains("google") && (c.contains("kholo") || c.contains("open")) -> openUrl("https://www.google.com")
            c.startsWith("search ") || c.startsWith(" खोज ") || c.contains("search karo") || c.contains("khojo") || c.contains(" खोजो") -> {
                val q = raw.replace(Regex("(?i)google par|google mein|search karo|search|khojo|खोजो|खोज|करो"), "").trim()
                openUrl("https://www.google.com/search?q=" + URLEncoder.encode(q.ifBlank { raw }, "UTF-8"))
                respond("Browser mein search khol diya hai.")
            }
            c.contains("note") || c.contains("नोट") -> {
                val note = raw.replace(Regex("(?i)^.*?(note likho|note|नोट लिखो|नोट)"), "").trim().ifBlank { raw }
                val old = prefs.getString("notes", "") ?: ""
                prefs.edit().putString("notes", (old + "\n• " + note).trim()).apply()
                respond("Note save kar diya: $note")
            }
            c.contains("show notes") || c.contains("notes dikhao") || c.contains("नोट दिखाओ") -> {
                respond(prefs.getString("notes", "Abhi koi note nahi hai.") ?: "Abhi koi note nahi hai.")
            }
            c.contains("remind") || c.contains("yaad dilana") || c.contains("याद दिलाना") || c.contains("reminder") -> {
                val mins = Regex("(\\d+)\\s*(minute|min|minutes|मिनट)").find(c)?.groupValues?.get(1)?.toLongOrNull() ?: 1L
                val message = raw.substringAfter("to ", raw.substringAfter("कि ", raw))
                scheduleReminder(message, mins.coerceIn(1, 10080))
            }
            c.contains("youtube") && (c.contains("video") || c.contains("वीडियो")) -> openUrl("https://www.youtube.com/results?search_query=" + URLEncoder.encode(raw, "UTF-8"))
            else -> askAi(raw)
        }
    }

    private fun askAi(prompt: String) {
        val key = prefs.getString("gemini_key", "") ?: ""
        if (key.isBlank()) {
            respond("Is command ka AI jawab dene ke liye API key chahiye. Neeche 'API key' button dabakar Gemini API key save karo. App-opening, notes aur browser actions bina key bhi kaam karte hain.")
            return
        }
        status.text = "AI soch raha hai…"
        executor.execute {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + URLEncoder.encode(key, "UTF-8"))
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject()
                body.put("system_instruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text",
                    "Tum MITHILA AI ho, ek helpful personal assistant. Hamesha Hindi ya natural Hinglish mein jawab do. Jawab saaf aur seedha rakho. Phone par action karne ka daava tabhi karo jab app ne waqai action kiya ho. Dangerous ya private action ke liye confirmation maango."))))
                body.put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt)))))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    .bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception("API error ${conn.responseCode}: $response")
                val text = JSONObject(response).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                runOnUiThread { status.text = "Hindi • Hinglish • Voice" }
                respond(text)
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Hindi • Hinglish • Voice" }
                respond("AI se connect nahi ho paya: ${e.message ?: "network error"}. Internet aur API key check karo.")
            }
        }
    }

    private fun askApiKey() {
        val field = EditText(this).apply {
            hint = "Gemini API key"
            setText(prefs.getString("gemini_key", "") ?: "")
            inputType = 129
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Gemini API key")
            .setMessage("Key isi phone par app preferences mein save hogi. Ise kisi ke saath share na karein.")
            .setView(field)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_key", field.text.toString().trim()).apply()
                respond("API key save kar di. Ab AI sawal pooch sakte ho.")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun startVoice() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Hindi ya Hinglish mein command boliye")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            startActivityForResult(intent, voiceRequest)
        } catch (_: Exception) {
            respond("Voice input service nahi mil rahi. Google app/voice typing install ya enable karo.")
        }
    }

    @Deprecated("legacy activity result works across supported Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) { input.setText(words); sendCommand() }
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            respond("Browser/app kholne ki request bhej di.")
        } catch (_: Exception) { respond("Is action ke liye compatible app nahi mili.") }
    }

    private fun scheduleReminder(message: String, minutes: Long) {
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("message", message)
        val pi = PendingIntent.getBroadcast(this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        try {
            val whenAt = System.currentTimeMillis() + minutes * 60_000
            if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
            else alarm.set(AlarmManager.RTC_WAKEUP, whenAt, pi)
            respond("$minutes minute baad reminder schedule kar diya. Message: $message")
        } catch (_: Exception) { respond("Reminder set nahi ho paya. Phone settings mein app notifications allow karo.") }
    }

    private fun respond(text: String) {
        addMessage("MITHILA AI", text)
        speak(text)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "mithila-${System.currentTimeMillis()}")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            tts.setSpeechRate(0.92f)
            tts.setPitch(0.82f) // lower pitch; actual male voice depends on installed TTS voice
            runOnUiThread {
                status.text = if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                    "Hindi TTS data install karo • Hinglish available" else "Hindi • Hinglish • Voice ready"
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
